# Software_Installer

I have added this Software installer script for all the developers to release their software 

This script is just start up point which can be extended upto great extent

Following features will be added in the installer

1) Latest UI
2) Setting registry
3) Checkpointing 
4) If previously installed version is not required then rollback facility
5) Uninstaller
6) Silent Installation
7) User input for optional installtion
8) Checksum validation

